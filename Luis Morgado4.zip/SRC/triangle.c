#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "triangle.h"
#include "drawline.h"

#define TRIANGLE_PENCOLOR   0xBBBB0000


// Print triangle coordinates along with a message
void PrintTriangle(triangle_t *triangle, char *msg)
{
    printf("%s: %d,%d - %d,%d - %d,%d\n",
        msg,
        triangle->x1, triangle->y1, 
        triangle->x2, triangle->y2, 
        triangle->x3, triangle->y3);
}


// Return 0 if triangle coordinates are outside the screen boundary. 1 otherwise.
int SanityCheckTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    if (triangle->sx1 < 0 || triangle->sx1 >= screen->w ||
        triangle->sx2 < 0 || triangle->sx2 >= screen->w ||
        triangle->sx3 < 0 || triangle->sx3 >= screen->w ||
        triangle->sy1 < 0 || triangle->sy1 >= screen->h ||
        triangle->sy2 < 0 || triangle->sy2 >= screen->h ||
        triangle->sy3 < 0 || triangle->sy3 >= screen->h) {
        return 0;
    } else {
        return 1;
    }
}


// Scale triangle
void ScaleTriangle(triangle_t *triangle)
{
    // TODO: Replace the code below with code that scales each triangle coordinate. 
    // The scaling factor is specified in triangle->scale.
    // Remember that this function MUST write to the on-screen coordinates.
    // Do not alter the model coordinates.
	
    triangle->sx1 = triangle->x1 * triangle->scale;      //
    triangle->sx2 = triangle->x2 * triangle->scale;      // Step 1: Scaling x-coordinates
    triangle->sx3 = triangle->x3 * triangle->scale;      //
	
	triangle->sy1 = triangle->y1 * triangle->scale;      //
    triangle->sy2 = triangle->y2 * triangle->scale;      // Step 1: Scaling y-coordinates
    triangle->sy3 = triangle->y3 * triangle->scale;      //
}


// Move triangle to its screen position
void TranslateTriangle(triangle_t *triangle)
{
    // TODO: Insert code that moves the triangle on the screen.
    // The translation coordinates are specified in triangle->tx and triangle->ty.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)
	
    triangle->tx = 512;  // Step 2: Center coordinate for x
	triangle->ty = 384;  // Step 2: Center coordinate for y
	
	triangle->sx1 = triangle->sx1 + triangle->tx;  //
    triangle->sx2 = triangle->sx2 + triangle->tx;  // Step 2: Position x-coordinates around the center
    triangle->sx3 = triangle->sx3 + triangle->tx;  //
	
	triangle->sy1 = triangle->sy1 + triangle->ty;  //
    triangle->sy2 = triangle->sy2 + triangle->ty;  // Step 2: Position y-coordinates around the center
    triangle->sy3 = triangle->sy3 + triangle->ty;  //
}


// Calculate triangle bounding box
void CalculateTriangleBoundingBox(triangle_t *triangle)
{
    // TODO: Insert code that calculates the bounding box of a triangle.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)
    // The bounding box coordinates should be written to 
    // triangle->bx, triangle->by, triangle->bw, triangle->bh
	
	if(triangle->sx1 <= triangle->sx2) {       //
		if(triangle->sx1 <= triangle->sx3) {   //
			triangle->bx = triangle->sx1;      //
		}                                      // 
		else {                                 //
			triangle->bx = triangle->sx3;      //
		}                                      //
	}                                          //
	                                           // Step 3: Check whitch one of the triangle x-coordinats has the lowest value
	if(triangle->sx2 <= triangle->sx1) {       //
		if(triangle->sx2 <= triangle->sx3) {   //
			triangle->bx = triangle->sx2;      //
		}                                      //
		else {                                 //
			triangle->bx = triangle->sx3;      //
		}                                      //
	}                                          //
	
	if(triangle->sx2 >= triangle->sx1) {       //
		if(triangle->sx2 >= triangle->sx3) {   //
			triangle->bw = triangle->sx2;      //
		}                                      // 
		else {                                 //
			triangle->bw = triangle->sx3;      //
		}                                      //
	}                                          //
	                                           // Step 3: Check whitch one of the triangle x-coordinats has the highest value
	if(triangle->sx1 >= triangle->sx2) {       //
		if(triangle->sx1 >= triangle->sx3) {   //
			triangle->bw = triangle->sx1;      //
		}                                      //
		else {                                 //
			triangle->bw = triangle->sx3;      //
		}                                      //
	}                                          //
	
	if(triangle->sy1 <= triangle->sy2) {       //
		if(triangle->sy1 <= triangle->sy3) {   //
			triangle->by = triangle->sy1;      //
		}                                      // 
		else {                                 //
			triangle->by = triangle->sx3;      //
		}                                      //
	}                                          //
	                                           // Step 3: Check whitch one of the triangle y-koordinats has the lowest value
	if(triangle->sy2 <= triangle->sy1) {       //
		if(triangle->sy2 <= triangle->sy3) {   //
			triangle->by = triangle->sy2;      //
		}                                      //
		else {                                 //
			triangle->by = triangle->sy3;      //
		}                                      //
	}                                          //
	
	if(triangle->sy2 >= triangle->sy1) {       //
		if(triangle->sy2 >= triangle->sy3) {   //
			triangle->bh = triangle->sy2;      //
		}                                      // 
		else {                                 //
			triangle->bh = triangle->sy3;      //
		}                                      //
	}                                          //
	                                           // Step 3: Check whitch one of the triangle y-coordinats has the highest value
	if(triangle->sy1 >= triangle->sy2) {       //
		if(triangle->sy1 >= triangle->sy3) {   //
			triangle->bh = triangle->sy1;      //
		}                                      //
		else {                                 //
			triangle->bh = triangle->sy3;      //
		}                                      //
	}                                          //
}


// Fill triangle with a color
void FillTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    // TODO: Insert code that fills the triangle with the color specified in triangle->fillcolor.
    // Hint: Draw the triangle with color TRIANGLE_PENCOLOR (this color can not
    // occur in e.g. the teapot or the example triangles).  Thus, if your 
    // approach to filling the triangle relies on looking for the edges of
    // the triangle on the screen (via the GetPixel function), you will find those
    // edges even if the triangle overlaps with a triangle that has already
    // been drawn on the screen.
	
	int Ymin = triangle->by;
	int Ymax = triangle->bh;
	int Xleft;
	int Xright;
		
	while (Ymin <= Ymax) {                   // Step 4: Functiom run through every y-coordinates inside the bounding box
		
		for (Xleft = triangle->bx; Xleft <= triangle->bw; Xleft++) {    // 
			if (GetPixel(screen, Xleft, Ymin) == TRIANGLE_PENCOLOR) {   //
				break;                                                  // Step 4: Find edge of the triangle from the left side
			}                                                           //
		}                                                               //
		
		for (Xright = triangle->bw; Xright >= Xleft; Xright--) {        //
			if (GetPixel(screen, Xright, Ymin) == TRIANGLE_PENCOLOR) {  //
				break;                                                  // Step 4: Find edge of the triangle from the right side
			}                                                           //
		}                                                               //
		
		if (GetPixel(screen, Xleft, Ymin) == TRIANGLE_PENCOLOR) {       //
			while(Xleft <= Xright) {                                    //
				SetPixel(screen, Xleft, Ymin, triangle->fillcolor);     // Step 4: Set a color between the left and right edge
				Xleft++;                                                //
			}                                                           //
		}                                                               //
		
		Ymin++;
	}
}

// Draw triangle on screen
void DrawTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    int isOK;
    
    // Scale.
    ScaleTriangle(triangle);
    
    // Translate.
    TranslateTriangle(triangle);
    
    // Determine bounding box
    CalculateTriangleBoundingBox(triangle);

    // Sanity check that triangle is within screen boundaries.
    isOK = SanityCheckTriangle(screen, triangle);
    if (isOK == 0) {
        PrintTriangle(triangle, "Triangle outside screen boundaries");
        return;
    }

    // TODO: Insert calls to DrawLine to draw the triangle.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)
	
	DrawLine(screen, triangle->sx1, triangle->sy1, triangle->sx2, triangle->sy2, TRIANGLE_PENCOLOR);  //
	DrawLine(screen, triangle->sx2, triangle->sy2, triangle->sx3, triangle->sy3, TRIANGLE_PENCOLOR);  // Draw a triangle by using three lines
	DrawLine(screen, triangle->sx3, triangle->sy3, triangle->sx1, triangle->sy1, TRIANGLE_PENCOLOR);  //
		
    // Fill triangle
    FillTriangle(screen, triangle);

    // Force screen update.  
    //SDL_UpdateRect(screen, triangle->bx, triangle->by, triangle->bw, triangle->bh);

    // Force update of entire screen.  Comment/remove this call and uncomment the above call
    // when your CalculateTriangleBoundingBox function has been implemented.
    SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}
