#include <stdio.h>
#include <stdlib.h>
#include "list.h"


/*
 * List implementation
 */
 
typedef struct listnode listnode_t;
struct listnode {
    listnode_t  *next;
    void        *item;
};

struct list {
    listnode_t *head;
    int numitems;
};


// Create new list
list_t *list_create(void)
{
	list_t *new_list = malloc(sizeof(list_t)); // Create a list
	new_list-> head = NULL;
	new_list-> numitems = 0;
	
	return new_list;
}

// Free list. items not freed.
void list_destroy(list_t *list)
{
    free(list);                 // Free the list
}


// Insert item first in list
int list_addfirst(list_t *list, void *item)
{
    listnode_t *first_node = malloc(sizeof(listnode_t)); //empty space in the memory
	
	first_node-> next = list-> head;   // set first_node before head
	list-> head = first_node;          // set first_node to be new head
	
	first_node-> item = item; // save item inside list
	list-> numitems += 1;     // list has one more item
	
	return list-> numitems;
}


// Insert item last in list.
int list_addlast(list_t *list, void *item)
{
    listnode_t *head = list-> head;
	listnode_t *last_node = malloc(sizeof(listnode_t)); 
	
	if(list-> head == NULL){              //
		return list_addfirst(list, item); // 
	}                                     //
	
	while(head-> next != NULL){  //
		head = head-> next;      // Find end of the list
	}                            //
	
	last_node-> next = head-> next;
	head-> next = last_node;
	
	last_node-> item = item;
	list-> numitems += 1;
	
	return list-> numitems;
}


// Remove item from list
void list_remove(list_t *list, void *item)
{
	int i;
	int N = list_size(list);
	listnode_t *head = list-> head;
	listnode_t *temp_node = NULL;
	
	if(head-> item == item){
		temp_node = head->next;   //
		free(head);               // Delete head pointer and set head->next, as the new head pointer
		list-> head = temp_node;  //
		
		list-> numitems--;        // We have one less item in the list
		return;                 
	}
	
	if(head-> item != item){
		for(i = 0; i < N; i++){             //
			if(head-> next-> item == item){ //
				break;                      // Find the previous node that we wish to destroy
			}                               //
		head = head-> next;                 //
		}                                   //
	
		temp_node = head-> next;       //
		head-> next = temp_node->next; // Link previoust node with temp_node->next and delete temp_node
		free(temp_node);               //
		
		list-> numitems--;
	}
}


// Return # of items in list
int list_size(list_t *list)
{
	return list-> numitems;
}



/*
 * Iterator implementation
 */
 

struct list_iterator {
    listnode_t *next;
    list_t *list;
};


// Create new list iterator
list_iterator_t *list_createiterator(list_t *list)
{
	list_iterator_t *iter = malloc(sizeof(list_iterator_t));
	
	iter-> next = list-> head;
	iter-> list = list;
	
	return iter;
}


// Free iterator
void list_destroyiterator(list_iterator_t *iter)
{
	free(iter);
}


// Move iterator to next item in list and return current.
void *list_next(list_iterator_t *iter)
{
    void *item = NULL;
	if(iter-> next == NULL){
		return NULL;
	}
	
	item = iter-> next-> item;
	iter-> next = iter-> next-> next;
	
	return item;
}


// Let iterator point to first item in list again
void list_resetiterator(list_iterator_t *iter)
{
	iter-> next = iter-> list-> head;
}




