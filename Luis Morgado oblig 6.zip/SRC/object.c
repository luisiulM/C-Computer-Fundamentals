#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "object.h"

// Create new object
object_t *CreateObject(SDL_Surface *screen, triangle_t *model, int numtriangles)
{
	
	object_t *new_object = malloc(sizeof(object_t)); // Make an empty space
	
    new_object-> scale = 0.1;
	new_object-> rotation = 1.0;
	new_object-> tx = 50;
	new_object-> ty = 50;
	
	new_object-> speedx = 0.00000;
	new_object-> speedy = 0.00000;
	new_object-> ttl = 0;
	new_object-> StartTime = 0;
	
	new_object-> numtriangles = numtriangles;
	new_object-> screen = screen;
	
	new_object-> model = malloc(sizeof(triangle_t) * numtriangles); // new memory
	memcpy(new_object->model, model, sizeof(triangle_t) * numtriangles); // copying a memory
	
	return new_object;
}


// Free memory used by object
void DestroyObject(object_t *object)
{
    free(object->model);
	free(object);
}


// Draw object on screen
void DrawObject(object_t *object)
{
	int a;
	for (a = 0; a < object->numtriangles; a++) {
		object-> model[a].scale = object-> scale;
		object-> model[a].rotation = object-> rotation;
		object-> model[a].tx = object-> tx;
		object-> model[a].ty = object-> ty;
		
		DrawTriangle(object->screen, &object-> model[a]);
	}
	
} 
