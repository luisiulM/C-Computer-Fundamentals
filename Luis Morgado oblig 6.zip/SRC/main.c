#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "list.h"
#include "teapot_data.h"
#include "sphere_data.h"
#include "object.h"
#include <time.h>

#define MIN(x,y) (x < y ? x : y)
#define MAX(x,y) (x > y ? x : y)


// Clear screen by filling it with 0
void ClearScreen(SDL_Surface *screen)
{
    SDL_Rect rect;
    
    // Define a rectangle covering the entire screen
    rect.x = 0;
    rect.y = 0;
    rect.w = screen->w;
    rect.h = screen->h;
    
    // And fill screen with 0
    SDL_FillRect(screen, &rect, 0);
}


void BouncingBalls(SDL_Surface *screen)
{
    
	int done = 0;
	int i = 0;
	int time = 0;
		
	SDL_Event event;
	
	list_t *ball_data = list_create(); // Create a list.
	
	object_t *ball; // Define object
	
	list_iterator_t *ball_list = list_createiterator(ball_data); // Create an iterator
	
	while (done == 0) {
		time = SDL_GetTicks();
		i += 2;
		
		if(rand() % 100 > 97 && list_size(ball_data) < 3){                  // 3% chance to create a ball
			ball = CreateObject(screen, sphere_model, SPHERE_NUMTRIANGLES); // Send in the sphere data.
			
			srand(i);                                                       //
			ball->speedx = 10.000000 + (rand() % 16);                       //  Make a random speedx
			
			list_addfirst(ball_data, ball);                                 // Link all the lists.
		}
	
		
		ClearScreen(screen); // Clear the screen
		
		list_resetiterator(ball_list);
		ball = list_next(ball_list);
		
		
		
		while(ball != NULL){  // has long as a ball exists
			
			DrawObject(ball); // Draw ball
			
			
			ball-> ty = ball-> ty + ball-> speedy;              //
			ball-> tx = ball-> tx + ball-> speedx;              // Move and rotate the ball
			ball-> rotation = ball-> rotation + ball-> speedx;  //
						
			if(ball-> tx >= 976){                       //
				ball-> speedx = (ball-> speedx * -1.0); // Bounce when hiting the right wall
			}                                           //
		
			if(ball-> tx <= 50){                        //
				ball-> speedx = (ball-> speedx * -1.0); // Bounce when hiting the left wall 
			}                                           //

			if(ball-> ty >= 650) {                      //
				ball-> speedy = ball-> speedy * -1.0;   // Bounce when hiting the floor
				ball-> speedy *= 0.90;                  //
			}                                           //
		
			if(ball->ty <= 50) {                        //
				ball-> speedy = ball-> speedy * -1.0;   // Bounce when hiting the roof
				ball-> speedy *= 0.90;                  //
			}                                           //
		
			ball-> speedy += 0.2;                                                 //
																				  //
			if(ball-> speedy < 0.1 && ball-> speedy > -0.1 && ball-> ty >= 650){  // Gravity
				ball-> speedy = 0;                                                //
				ball-> ty = 650;                                                  //
			}                                                                     //
		
		
			ball-> speedx *= 0.995;                                    // Air resistance
		
			if(ball-> ty == 650 && ball-> speedy == 0){               //
				if(ball-> speedx < 0){                                //
					ball-> speedx += 0.003;                           // 
				}                                                     //
			                                                          //
				if(ball-> speedx > 0){                                //   
					ball-> speedx -= 0.003;                           // Friction between the ball and the floor
				}                                                     //
																	  //
				if(ball-> speedx < 0.003 && ball-> speedx > -0.003){  //
					ball-> speedx = 0;                                //
				}                                                     //
			}                                                         //
			
			
			if(ball-> speedx == 0 && ball-> speedy == 0){            //
				ball-> StartTime += SDL_GetTicks() - time;           //
			}                                                        // Countdown timer.
			                                                         //
			ball-> ttl = ball-> StartTime / 1000;                    //
			
			
			if(ball-> ttl > 4 && ball-> speedx == 0 && ball-> speedy == 0){  //
				list_remove(ball_data, ball);                                 // Destroy the ball after 5 sec.
				DestroyObject(ball);                                          //
			}                                                                 //
			
			ball = list_next(ball_list);  // Move the next ball in the list
		}
		
		SDL_Flip(screen);
				
						
		while (SDL_PollEvent(&event)) { //
            switch (event.type) {       //
            case SDL_QUIT:              //
                done = 1;               // quit by clicking the close button
                break;                  //
            }                           //
        }                               //
	}
}


// First function run in your program
int main(int argc, char **argv)
{
    int retval;
    SDL_Surface *screen;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);
    }
    
    // Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 700, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

    // Start bouncing some balls
    BouncingBalls(screen);

    // Shut down SDL    
    SDL_Quit();

    // Wait a little bit jic something went wrong (so that printfs can be read)
    SDL_Delay(5000);
    
    return 0;
}
