# include <stdio.h>

int mylog2(unsigned int n)
{
	int shift;
	int power = 0;
	
	while(n > 1) {       //
		shift = n >> 1;  //
		n = shift;       // while loop
		power++;         //
	}                    //
	
	return n = power;
}

int main()
{
	int n;
	int result;
 
    printf("Enter a number: ");
    scanf("%d",&n);
	 
    result = mylog2(n);
	
	printf("The binary logarithm of %d is %d",n , result);
}