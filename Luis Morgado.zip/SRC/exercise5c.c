#include <stdio.h>

int main(void)
{
	int i;
	i = 5;
	
	while (i >= 0) {
	    printf("%d\n", i);
		
		i = i-1;;
	}
}