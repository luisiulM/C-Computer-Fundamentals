#include <stdio.h>

int main()
{
	int number;   // step 1
	int answer;   //
	
	printf ("Please, pick a number: ");  
	scanf("%d", &number);	             // step 2
	
	answer = multiplied(number); // step 4
	
	printf("The number %d multiplied by 5 is %d\n", number, answer); //step 5
}


int multiplied(int number)// Step 3
{
	int result;
	
	result = number * 5;
	
	return result;
}