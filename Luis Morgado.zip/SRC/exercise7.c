#include <stdio.h>

void mynumber(void) // Step 2
{
	int number = 1;
	int result;
	int prime = 5; // Step 4
			
	while(number <= 50){                      //  [
		if (number & 1 == 1){                 //
			printf("%d is odd and", number);  //
		}                                     // Step 3
		else{                                 //
			printf("%d is even and", number); //
		}                                     //  ]
		
		if(number % prime > 0){                             //  [
			printf(" 5 is not a prime factor\n\n", number); //
		}                                                   // Step 4
		if (number % prime == 0){                           //
			printf(" 5 is a prime factor\n\n", number);     //
		}                                                   //  ]
		
		number++;
	 }
}

int main() // Step 1
{
	mynumber();
}