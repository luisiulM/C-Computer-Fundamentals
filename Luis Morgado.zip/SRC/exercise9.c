#include <stdio.h>

int main(void)
{
	float celsius = 0; // Step 1
	float fahrenheit;  // 
	
	while(celsius <= 50) { // Step 2
		fahrenheit = (1.8 * celsius) + 32; // Step 3
		printf("The temperature %.0f in celsius is equal to %.2f in fahrenheit\n", celsius, fahrenheit); // Step 4
		
		celsius++;
	}
}