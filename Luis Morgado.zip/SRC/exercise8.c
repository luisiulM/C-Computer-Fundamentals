#include <stdio.h>

void mytriangles(int numlines) // Step 2
{
	int line = 1;                               // (
	int stars;                                  //
	                                            //
	while(line <= numlines)                     //
	{                                           //
		for(stars = 1; stars <= line; stars++){ //
			printf("*");                        // Step 3
			                                    //
		}                                       //
                                                //  
        printf("\n");                           //
		                                        //
		line++;                                 //
	}                                           // )
}

int main()                       // (
{                                //
	int numlines;                //
                                 // Step 1
    printf("How many lines: ");  //
    scanf("%d",&numlines);       // )
	 
    mytriangles(numlines); // Step 4
}