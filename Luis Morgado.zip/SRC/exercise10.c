# include <stdio.h>

int main(void)
{
	int number;
	int rest;
	
	printf("Enter an integer: ");
	scanf("%d", &number);
	
	printf("The reversed integer is ");
	
	while(number != 0) {        //
		rest = number%10;       //
		printf("%d",rest);      // while loop
		number = number/10;     //
	}                           //
}